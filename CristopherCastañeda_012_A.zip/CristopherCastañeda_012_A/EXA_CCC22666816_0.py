



def leer_opcion():
    while True:
        try:
            opcion = int(input("Seleccione una opcion: "))
            if 1 <= opcion <= 6:
                return opcion
            else:
                print("Debes seleccionar una opcion valida")
        except ValueError:
            print("Debes seleccionar una opcion que sea valida")

def stock_plataforma(plataforma, dicc_juegos, dicc_inventario):
    total_stock = 0
    plat_busqueda = plataforma.strip().lower()
    for codigo, datos in dicc_juegos.items():
        if datos[1].lower() == plat_busqueda:
            if codigo in dicc_inventario:
                total_stock += dicc_inventario[codigo][1]
    print(f"El total de stock disponibles es: {total_stock}")

def busqueda_precio(p_min, p_max, dicc_juegos, dicc_inventario):
    resultados = []
    for codigo, datos_inv in dicc_inventario.items():
        precio = datos_inv[0]
        stock = datos_inv[1]
        if p_min <= precio <= p_max and stock > 0:
            if codigo in dicc_juegos:
                titulo = dicc_juegos[codigo][0]
                resultados.append(f"{titulo}--{codigo}")
    
    if len(resultados) == 0:
        print("No hay juegos en ese rango de precios.")
    else:
        resultados.sort()
        print(f"Los juegos encontrados son: {resultados}")

def buscar_codigo(codigo, dicc_inventario):
    cod_busqueda = codigo.strip().upper()
    for k in dicc_inventario.keys():
        if k.upper() == cod_busqueda:
            return True
    return False

def obtener_clave_real(codigo, dicc_inventario):
    cod_busqueda = codigo.strip().upper()
    for k in dicc_inventario.keys():
        if k.upper() == cod_busqueda:
            return k
    return codigo.strip().upper()

def actualizar_precio(codigo, nuevo_precio, dicc_inventario):
    if buscar_codigo(codigo, dicc_inventario):
        clave_real = obtener_clave_real(codigo, dicc_inventario)
        dicc_inventario[clave_real][0] = nuevo_precio
        return True
    return False

def val_codigo(codigo, dicc_juegos):
    if codigo.strip() == "":
        return False
    if buscar_codigo(codigo, dicc_juegos):
        return False
    return True

def val_titulo(titulo):
    return titulo.strip() != ""

def val_plataforma(plataforma):
    return plataforma.strip() != ""

def val_genero(genero):
    return genero.strip() != ""

def val_clasificacion(clasificacion):
    return clasificacion.strip() in ["E", "T", "M"]

def val_multiplayer(mp_str):
    return mp_str.strip().lower() in ["s", "n"]

def val_editor(editor):
    return editor.strip() != ""

def val_precio(precio_str):
    try:
        val = int(precio_str)
        return val > 0
    except ValueError:
        return False

def val_stock(stock_str):
    try:
        val = int(stock_str)
        return val >= 0
    except ValueError:
        return False

def agregar_juego(codigo, titulo, plataforma, genero, clasificacion, multiplayer, editor, precio, stock, dicc_juegos, dicc_inventario):
    cod_alta = codigo.strip().upper()
    if buscar_codigo(cod_alta, dicc_juegos):
        return False
    
    mp_bool = True if multiplayer.strip().lower() == "s" else False
    
    dicc_juegos[cod_alta] = [
        titulo.strip(),
        plataforma.strip(),
        genero.strip(),
        clasificacion.strip(),
        mp_bool,
        editor.strip()
    ]
    
    dicc_inventario[cod_alta] = [int(precio), int(stock)]
    return True

def eliminar_juego(codigo, dicc_juegos, dicc_inventario):
    if buscar_codigo(codigo, dicc_inventario):
        clave_real = obtener_clave_real(codigo, dicc_inventario)
        del dicc_juegos[clave_real]
        del dicc_inventario[clave_real]
        return True
    return False


juegos = {
    'G001': ['Eclipse Runner', 'PC', 'accion', 'T', True, 'NovaStudio'],
    'G002': ['Puzzle Atlas', 'Switch', 'puzzle', 'E', False, 'BrightWorks'],
    'G003': ['Sky Legends', 'PS5', 'aventura', 'T', True, 'OrionGames'],
    'G004': ['Racing Pulse', 'PC', 'carreras', 'E', True, 'VelocityLab'],
    'G005': ['Mystic Farm', 'Switch', 'simulacion', 'E', False, 'GreenSeed'],
    'G006': ['Shadow Tactics', 'Xbox', 'estrategia', 'M', False, 'IronGate']
}

inventario = {
    'G001': [9990, 7],
    'G002': [19990, 0],
    'G003': [42990, 3],
    'G004': [14990, 5],
    'G005': [17990, 9],
    'G006': [39990, 2]
}

ejecutando = True

while ejecutando:
    print("========== MENU PRINCIPAL ==========")
    print("1. stock por plataforma")
    print("2. busqueda de juegos por rango de precio")
    print("3. actualizar precio de juego")
    print("4. agregar juego")
    print("5. borrar juego")
    print("6. Salir")
    print("=====================================")
    
    opcion = leer_opcion()
    
    if opcion == 1:
        plat = input("Ingrese la plataforma para consultar: ")
        stock_plataforma(plat, juegos, inventario)
        
    elif opcion == 2:
        while True:
            try:
                p_min = int(input("Ingrese precio minimo: "))
                p_max = int(input("Ingrese precio maximo: "))
                if p_min >= 0 and p_max >= 0 and p_min <= p_max:
                    busqueda_precio(p_min, p_max, juegos, inventario)
                    break
                else:
                    print("Debes ingresar valores enteros que sean validos (minimmo menor o igual al maximo)")
            except ValueError:
                print("Debes ingresar valores enteros")
                
    elif opcion == 3:
        bucle_precio = True
        while bucle_precio:
            cod = input("Ingrese el codigo del juego: ")
            try:
                nuevo_p = int(input("Ingrese el nuevo precio: "))
                if nuevo_p > 0:
                    if actualizar_precio(cod, nuevo_p, inventario):
                        print("Precio actualizado")
                    else:
                        print("El codigo no existe")
                else:
                    print("El precio debe ser un entero positivo")
            except ValueError:
                print("El precio debe ser un entero válido")
            
            resp = input("¿Desea actualizar otro precio (s/n)?: ").strip().lower()
            if resp != "s":
                bucle_precio = False
                
    elif opcion == 4:
        c_cod = input("Ingrese el codigo del juego: ")
        c_tit = input("Ingrese el titulo: ")
        c_plat = input("Ingrese la plataforma: ")
        c_gen = input("Ingrese el genero: ")
        c_cla = input("Ingrese la clasificacion: ")
        c_mp = input("¿Es multiplayer? (s/n): ")
        c_edi = input("Ingrese el editor: ")
        c_pre = input("Ingrese el precio: ")
        c_sto = input("Ingrese el stock: ")
        
        todo_correcto = True
        
        if not val_codigo(c_cod, juegos):
            print("Error: Código vacío o ya existente.")
            todo_correcto = False
        elif not val_titulo(c_tit):
            print("Error: Título inválido.")
            todo_correcto = False
        elif not val_plataforma(c_plat):
            print("Error: Plataforma inválida.")
            todo_correcto = False
        elif not val_genero(c_gen):
            print("Error: Género inválido.")
            todo_correcto = False
        elif not val_clasificacion(c_cla):
            print("Error: Clasificación inválida (debe ser E, T o M).")
            todo_correcto = False
        elif not val_multiplayer(c_mp):
            print("Error: Entrada de multiplayer inválida (s/n).")
            todo_correcto = False
        elif not val_editor(c_edi):
            print("Error: Editor inválido.")
            todo_correcto = False
        elif not val_precio(c_pre):
            print("Error: Precio inválido (debe ser entero mayor a 0).")
            todo_correcto = False
        elif not val_stock(c_sto):
            print("Error: Stock inválido (debe ser entero mayor o igual a 0).")
            todo_correcto = False
            
        if todo_correcto:
            if agregar_juego(c_cod, c_tit, c_plat, c_gen, c_cla, c_mp, c_edi, c_pre, c_sto, juegos, inventario):
                print("Juego agregado")
            else:
                print("El código ya existe")
                
    elif opcion == 5:
        cod_del = input("Ingrese el código del juego a eliminar: ")
        if eliminar_juego(cod_del, juegos, inventario):
            print("Juego eliminado")
        else:
            print("El codigo no existe")
            
    elif opcion == 6:
        print("Programa terminado.")
        ejecutando = False
